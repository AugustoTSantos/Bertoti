# Consulta da API Via CEP

Projeto desenvolvido durante estudos sobre API.
Para acessar clique [AQUI](https://consulta-api-via-cep.vercel.app/)


